if (location.href === "https://www.mz.jena.de/moodle/") {
  var loginContA = document.querySelector(".usermenu .login a");
  console.log({ loginContA });
  if (loginContA) {
    location.replace("https://www.mz.jena.de/moodle/login/index.php");
  }
}
/*else if (location.href === "https://www.mz.jena.de/moodle/login/index.php") {
  var userIn = false;
  var passIn = false;
  document.getElementById("password").addEventListener("input", (e) => {
    if (e.isTrusted === false && e.target.value.length === 25) {
      userIn = true;
      checkAndLogin();
    }
  });
  document.getElementById("username").addEventListener("input", (e) => {
    if (e.isTrusted === false && e.target.value.length === 3) {
      passIn = true;
      checkAndLogin();
    }
  });
  function checkAndLogin() {
    if (userIn && passIn) {
      document.getElementById("loginbtn").click();
    }
  }
}*/

if (
  location.pathname.slice(-4) === ".pdf"

  // && href.slice(href.length - forceDownload.length) !== forceDownload
) {
  const forceDownload = "forcedownload=1";
  location.search = forceDownload;
}

if (location.href === "https://www.mz.jena.de/moodle/my/") {
  //console.log(String(document.querySelector("#block-region-content")));
  const Fächer = {
    Kunst: "🎨",
    Astronomie: "✨",
    Ethik: null,
    Sport: "🏀",
    Englisch: null,
    Deutsch: null,
    Französisch: "🥖",
    Mathe: "📊",
    Biologie: "🌸",
    Chemie: "🧪",
    Geographie: "🌎",
    Musik: "🎶",
    Physik: "⚛️",
    Sozialkunde: null,
    WR: "📈",
    Geschichte: null,
    Informatik: "👩‍💻",
  };
  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      console.log("Mutation");

      document
        .querySelectorAll(".card-deck .card[data-region='course-content']")
        .forEach((item) => {
          try {
            const name =
              item.children[1].children[0].children[0].children[1].children[2]
                .textContent;
            const filtered = Object.keys(Fächer).filter((item) =>
              name.includes(item)
            );

            if (filtered.length === 1) {
              item.children[1].children[0].children[0].children[1].children[2].textContent =
                filtered[0];
              item.children[1].children[0].children[0].children[0].children[1].textContent =
                "";

              if (Fächer[filtered[0]] != null) {
                console.log(
                  "setBgImage",
                  item.children[0].children[0].style.backgroundImage
                );

                item.children[0].children[0].style.backgroundImage = `url("\
data:image/svg+xml;utf8, \
  <svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='170px' height='50px'> \
    <rect x='0' y='0' width='170' height='50'\
      style=' \
             \
             fill:gray;  fill-opacity: 0.7; '/> \
    <text x='85' y='30' \
      style='fill:lightBlue; text-anchor: middle' font-size='24' \
      transform=''> \
      ${Fächer[filtered[0]]} \
    </text> \
  </svg>\
")`;
              }
            }
          } catch (err) {
            console.warn(err);
          }
        });
    });
  });

  // Configuration of the observer:
  var config = {
    attributes: true,
    childList: true,
    characterData: true,
    subtree: true,
  };

  // Pass in the target node, as well as the observer options
  observer.observe(document.querySelector("#block-region-content"), config);
}
