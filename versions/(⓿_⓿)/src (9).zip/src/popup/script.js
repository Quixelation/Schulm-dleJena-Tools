var accordionEl = document.getElementsByClassName("accordion");
var accordionElI;
for (accordionElI = 0; accordionElI < accordionEl.length; accordionElI++) {
    accordionEl[accordionElI].addEventListener("click", function () {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        }
        else {
            panel.style.display = "block";
        }
    });
}
chrome.storage.sync.get(null, function (options) {
    var Fächer = options["fächer"];
    console.log(Fächer);
    //document.writeln("Value currently is " + result.key);
    document.getElementById("loading").remove();
    document.getElementById("content").style.display = "unset";
    console.log(options);
    new moodleHelperCheckbox("autologinredirect", options);
    new moodleHelperCheckbox("shortcoursenames", options);
    new moodleHelperCheckbox("usecoloredprogress", options);
    new moodleHelperCheckbox("showemojicourses", options);
    new moodleHelperCheckbox("autodashboardredirect", options);
    new moodleHelperCheckbox("forcedownload", options);
    new moodleHelperCheckbox("autologin_untrusted", options);
    Object.keys(Fächer).forEach(function (FachName) {
        createRow(FachName, Fächer[FachName]);
    });
});
var dict = {
    autologinredirect: {
        name: "Auto Login-Redirect",
        desc: "Automatisch zur Login-Seite gehen."
    },
    shortcoursenames: {
        name: "Kurze Kursnamen",
        desc: "Kursnamen werden gekürzt."
    },
    usecoloredprogress: {
        name: "Farbiger Fortschritt",
        desc: "Kursname wird je nach Fortschritt gefärbt. (von rot zu grün)"
    },
    showemojicourses: {
        name: "Emoji-Kursbilder",
        desc: "Kurse haben Emojis als Thumbnails."
    },
    autodashboardredirect: {
        name: "Auto Dashboard",
        desc: "Startseite leitet automatisch zum Dashboard weiter."
    },
    forcedownload: {
        name: "Download erzwingen",
        desc: "Dateien werden automatisch heruntergeladen"
    },
    autologin_untrusted: {
        name: "AutoFill-AutoLogin",
        desc: "UntrustedEvents (Autofill): Automatischen Klicken des Einloggen Knopfes."
    }
};
var moodleHelperCheckbox = /** @class */ (function () {
    function moodleHelperCheckbox(id, options) {
        var createdTr = document.createElement("tr");
        var detailsTd = document.createElement("td");
        detailsTd.style.fontWeight = "bold";
        detailsTd.style.fontSize = "1.2em";
        var descDiv = document.createElement("div");
        descDiv.innerText = dict[id].desc;
        descDiv.style.fontSize = "0.9em";
        descDiv.style.fontWeight = "400";
        var checkboxTd = document.createElement("td");
        var checkboxElem = document.createElement("input");
        checkboxElem.setAttribute("type", "checkbox");
        checkboxElem.checked = options[id] || false;
        checkboxElem.addEventListener("input", function (e) {
            var _a;
            chrome.storage.sync.set((_a = {}, _a[id] = e.target.checked, _a), function () {
                console.log("Value is set to ", e.target.checked);
                document.getElementById("needToReload").style.display = "unset";
            });
        });
        detailsTd.innerText = dict[id].name;
        detailsTd.appendChild(descDiv);
        createdTr.appendChild(detailsTd);
        checkboxTd.appendChild(checkboxElem);
        createdTr.appendChild(checkboxTd);
        document.getElementById("optionsTable").appendChild(createdTr);
    }
    return moodleHelperCheckbox;
}());
document.getElementById("needToReload").onclick = reload;
function reload() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
    });
}
document.getElementById("addBtn_emojiTable").addEventListener("click", function () {
    createRow();
});
function makeid(length) {
    var result = "";
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}
function createRow(content1, content2) {
    var table = document.querySelector("table#emojiTable");
    var number = table.children[0].childElementCount;
    var row = table.insertRow(number);
    row.id = Date.now().toString() + makeid(5) + "__rowKurse";
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    cell1.innerHTML = "<input placeholder=\"Fach\" value=\"" + content1 + "\" />";
    cell2.innerHTML = "<input placeholder=\"Emoji\" value=\"" + content2 + "\" />";
    cell3.innerHTML = "<button>\uD83D\uDEAE</button>";
    cell3.addEventListener("click", function (e) {
        var parentTr = e.target.parentElement.parentElement;
        var parentTable = parentTr.parentElement;
        var children = [];
        for (var child in parentTable.children) {
            if (!isNaN(parseInt(child))) {
                if (child == "length")
                    return;
                if (child == "0")
                    continue;
                children.push(parentTable.children[child]);
            }
        }
        var lookingForNumber;
        children.forEach(function (item, index) {
            if (item.id === parentTr.id) {
                lookingForNumber = index + 1;
            }
        });
        console.log(lookingForNumber);
        table.deleteRow(lookingForNumber);
    });
}
document.getElementById("saveBtn_emojiTable").addEventListener("click", function () {
    var table = document.querySelector("table#emojiTable");
    var newFächer = {};
    for (var child in table.children[0].children) {
        if (!isNaN(parseInt(child))) {
            if (child == "0")
                continue;
            var name = table.children[0].children[child].children[0]
                .children[0].value;
            var emoji = table.children[0].children[child].children[1]
                .children[0].value;
            newFächer[name] = emoji;
        }
    }
    chrome.storage.sync.set({ fächer: newFächer }, function () {
        reload();
    });
});
