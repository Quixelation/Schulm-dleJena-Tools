//@ts-nocheck
console.log("script.js");
chrome.runtime.sendMessage({ message: "activate_icon" });
chrome.storage.sync.get(null, function (options) {
    if (location.href === "https://www.mz.jena.de/moodle/") {
        var loginContA = document.querySelector(".usermenu .login a");
        console.log({ loginContA: loginContA });
        if (loginContA && options["autologinredirect"] === true) {
            location.replace("https://www.mz.jena.de/moodle/login/index.php");
        }
        else if (options["autodashboardredirect"] === true) {
            location.replace("https://www.mz.jena.de/moodle/my/");
        }
    }
    else if (location.href === "https://www.mz.jena.de/moodle/login/index.php") {
        var userIn = false;
        var passIn = false;
        document.getElementById("password").addEventListener("input", function (e) {
            if (true) {
                userIn = true;
                checkAndLogin();
            }
        });
        document.getElementById("username").addEventListener("input", function (e) {
            if (true) {
                passIn = true;
                checkAndLogin();
            }
        });
        function checkAndLogin() {
            console.log({ passIn: passIn, userIn: userIn });
            if (userIn && passIn && options["autologin_untrusted"]) {
                document.getElementById("loginbtn").click();
            }
        }
    }
    if (location.pathname.slice(-4) === ".pdf" &&
        options["forcedownload"] === true
    // && href.slice(href.length - forceDownload.length) !== forceDownload
    ) {
        var forceDownload = "forcedownload=1";
        location.search = forceDownload;
    }
    if (location.href === "https://www.mz.jena.de/moodle/my/") {
        //console.log(String(document.querySelector("#block-region-content")));
    }
});
document.querySelector(".site-name").innerHTML += "\n  <span style=\"font-size: 0.75rem; display: block;margin-top: -4px\">w/ Moodle-Helper by Robert St\u00FCndl</span>\n";
