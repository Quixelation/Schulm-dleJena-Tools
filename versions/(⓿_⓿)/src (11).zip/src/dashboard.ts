chrome.storage.sync.get(null, function (options) {
  const Fächer = options["fächer"];
  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      console.log("Mutation");

      document
        .querySelectorAll(".card-deck .card[data-region='course-content']")
        .forEach((item) => {
          if (item.getAttribute("data-moodlehelperenhanced") == "true") {
            return;
          } else {
            item.setAttribute("data-moodlehelperenhanced", "true");
          }
          console.log("Changing Dashboard");

          // Rremove not need white bg
          let bgWhiteTempItem = item.querySelector(".bg-white");
          if (bgWhiteTempItem) {
            bgWhiteTempItem.classList.remove("bg-white");
          }

          // try {
          //   item.querySelector(".progress-bar.bar").remove();
          // } catch (err) {}
          try {
            const name =
              item.children[1].children[0].children[0].children[1].children[2]
                .textContent;
            const filtered = Object.keys(Fächer).filter((item) =>
              name.includes(item)
            );

            if (filtered.length === 1) {
              if (options["shortcoursenames"] === true) {
                item.children[1].children[0].children[0].children[1].children[2].textContent =
                  filtered[0];
                (item.children[1].children[0].children[0].children[1]
                  .children[2] as HTMLSpanElement).style.fontSize = "20px";
                item.children[1].children[0].children[0].children[0].children[1].textContent =
                  "";
              }

              if (
                /*Gibt Emoji für dieses Fach*/ Fächer[filtered[0]] != null &&
                Fächer[filtered[0]] != "" &&
                Fächer[filtered[0]] != false &&
                Fächer[filtered[0]] != undefined &&
                options["showemojicourses"] === true
              ) {
                (item.children[0]
                  .children[0] as HTMLDivElement).style.backgroundImage = `url("\
data:image/svg+xml;utf8, \
  <svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='170px' height='50px'> \
    <rect x='0' y='0' width='170' height='50'\
      style=' \
             \
             fill:%23334155 ;  fill-opacity: 0.7; '/> \
    <text x='85' y='30' \
      style='fill:%2339CCCC; text-anchor: middle; font-family:Arial' font-size='24' \
      transform=''> \
      ${Fächer[filtered[0]]} \
    </text> \
  </svg>\
")`;
              }
            }
            // Wenn nicht 100% Fortschritt, dann Titel Fett
            if (
              item
                .querySelector(".progress-bar.bar")
                ?.getAttribute("aria-valuenow") != "100"
            ) {
              (item.children[1].children[0].children[0].children[1]
                .children[2] as HTMLSpanElement).style.fontWeight = "bold";
            }

            (item as HTMLDivElement).style.backgroundColor = "#0f172a";
            var smallFooterCard = item.querySelector(
              ".card-footer .small"
            ) as HTMLSpanElement;
            if (smallFooterCard) smallFooterCard.style.color = "#cbd5e1";

            try {
              (item.children[1].children[0].children[0].children[1]
                .children[2] as HTMLSpanElement).style.color = `#39CCCC`;
              var theProgressBar = item.querySelector(
                ".progress-bar.bar"
              ) as HTMLDivElement;
              if (theProgressBar) {
                theProgressBar.style.backgroundColor = `#39CCCC`;
              }
            } catch (err) {
              console.error("Default Colors Assign Error!", err);
            }

            if (options["usecoloredprogress"] === true) {
              if (item.querySelector(".progress-bar.bar") != null) {
                const maxChars = 100;

                var Hsl =
                  (Number(
                    item
                      .querySelector(".progress-bar.bar")
                      .getAttribute("aria-valuenow")
                  ) *
                    127) /
                  100;
                (item.children[1].children[0].children[0].children[1]
                  .children[2] as HTMLSpanElement).style.color = `hsla(${Hsl}, 100%, 50%, 1)`;
                (item.querySelector(
                  ".progress-bar.bar"
                ) as HTMLDivElement).style.backgroundColor = `hsla(${Hsl}, 100%, 50%, 1)`;
              }
            }
          } catch (err) {
            console.warn(err);
          }
        });
    });
  });

  // Configuration of the observer:
  var config = {
    attributes: true,
    childList: true,
    characterData: true,
    subtree: true,
  };

  // Pass in the target node, as well as the observer options
  observer.observe(document.querySelector("#block-region-content"), config);
});
