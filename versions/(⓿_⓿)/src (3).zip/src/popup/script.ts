chrome.storage.sync.get(null, function (options) {
  //document.writeln("Value currently is " + result.key);
  document.getElementById("loading").remove();
  document.getElementById("content").style.display = "unset";

  console.log(options);
  new moodleHelperCheckbox("autologinredirect", options);
  new moodleHelperCheckbox("usecoloredprogress", options);
  new moodleHelperCheckbox("showemojicourses", options);
});

const dict = {
  autologinredirect: {
    name: "Auto Login-Redirect",
  },
  usecoloredprogress: {
    name: "Farbiger Fortschritt",
  },
  showemojicourses: { name: "Emoji-Kursbilder" },
};

class moodleHelperCheckbox {
  constructor(id, options) {
    var createdTr = document.createElement("tr");
    var detailsTd = document.createElement("td");
    detailsTd.style.fontWeight = "bold";
    detailsTd.style.fontSize = "1.2em";
    var checkboxTd = document.createElement("td");
    var checkboxElem = document.createElement("input");
    checkboxElem.setAttribute("type", "checkbox");
    checkboxElem.checked = options[id] || false;
    checkboxElem.addEventListener("input", (e) => {
      chrome.storage.sync.set(
        { [id]: (e.target as HTMLInputElement).checked },
        () => {
          console.log(
            "Value is set to ",
            (e.target as HTMLInputElement).checked
          );
          document.getElementById("needToReload").style.display = "unset";
        }
      );
    });
    detailsTd.innerText = dict[id].name;
    createdTr.appendChild(detailsTd);
    checkboxTd.appendChild(checkboxElem);
    createdTr.appendChild(checkboxTd);
    document.getElementById("optionsTable").appendChild(createdTr);
  }
}

document.getElementById("needToReload").onclick = reload;
function reload() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.update(tabs[0].id, { url: tabs[0].url });
  });
}
