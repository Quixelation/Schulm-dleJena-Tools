//@ts-ignore
chrome.extension.onMessage.addListener(function (
  request,
  sender,
  sendResponse
) {
  console.log({ request, sender, sendResponse });
  if (request.message === "activate_icon") {
    chrome.pageAction.show(sender.tab.id);
  }
});

chrome.storage.sync.get(null, function (options) {
  if (Object.keys(options).length === 0) {
    chrome.storage.sync.set({
      usecoloredprogress: true,
      showemojicourses: true,
      autologinredirect: true,
      forcedownload: true,
      autodashboardredirect: true,
      autologin_untrusted: false,
    });
  }
});
