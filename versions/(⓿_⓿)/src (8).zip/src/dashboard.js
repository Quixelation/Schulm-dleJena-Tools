chrome.storage.sync.get(null, function (options) {
  var Fächer = options["fächer"];
  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      console.log("Mutation");
      document
        .querySelectorAll(".card-deck .card[data-region='course-content']")
        .forEach(function (item) {
          try {
            item.querySelector(".progress-bar.bar").remove();
            var name_1 =
              item.children[1].children[0].children[0].children[1].children[2]
                .textContent;
            var filtered = Object.keys(Fächer).filter(function (item) {
              return name_1.includes(item);
            });
            if (filtered.length === 1) {
              if (options["shortcoursenames"] === true) {
                item.children[1].children[0].children[0].children[1].children[2].textContent =
                  filtered[0];
                item.children[1].children[0].children[0].children[1].children[2].style.fontSize =
                  "20px";
                item.children[1].children[0].children[0].children[0].children[1].textContent =
                  "";
              }
              if (
                /*Gibt Emoji für dieses Fach*/ Fächer[filtered[0]] != null &&
                Fächer[filtered[0]] != "" &&
                Fächer[filtered[0]] != false &&
                Fächer[filtered[0]] != undefined &&
                options["showemojicourses"] === true
              ) {
                item.children[0].children[0].style.backgroundImage =
                  "url(\"data:image/svg+xml;utf8,   <svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='170px' height='50px'>     <rect x='0' y='0' width='170' height='50'      style='                           fill:gray;  fill-opacity: 0.7; '/>     <text x='85' y='30'       style='fill:lightBlue; text-anchor: middle' font-size='24'       transform=''>       " +
                  Fächer[filtered[0]] +
                  '     </text>   </svg>")';
              }
            }
            // Wenn nicht 100% Fortschritt, dann Titel Fett
            if (
              item
                .querySelector(".progress-bar.bar")
                ?.getAttribute("aria-valuenow") != "100"
            ) {
              item.children[1].children[0].children[0].children[1].children[2].style.fontWeight =
                "bold";
            }
            // Rremove not need white bg
            var bgWhiteTempItem = item.querySelector(".bg-white");
            if (bgWhiteTempItem) {
              bgWhiteTempItem.classList.remove("bg-white");
            }
            item.style.backgroundColor = "#0f172a";
            item.querySelector(".card-footer .small").style.color = "#cbd5e1";
            if (options["usecoloredprogress"] === true) {
              if (item.querySelector(".progress-bar.bar") != null) {
                var maxChars = 100;
                var Hsl =
                  (Number(
                    item
                      .querySelector(".progress-bar.bar")
                      .getAttribute("aria-valuenow")
                  ) *
                    127) /
                  100;
                item.children[1].children[0].children[0].children[1].children[2].style.color =
                  "hsla(" + Hsl + ", 100%, 50%, 1)";
                item.querySelector(".progress-bar.bar").style.backgroundColor =
                  "hsla(" + Hsl + ", 100%, 50%, 1)";
              } else {
                item.children[1].children[0].children[0].children[1].children[2].style.color =
                  "#39CCCC";
                item.querySelector(".progress-bar.bar").style.backgroundColor =
                  "#39CCCC";
              }
            }
          } catch (err) {
            console.warn(err);
          }
        });
    });
  });
  // Configuration of the observer:
  var config = {
    attributes: true,
    childList: true,
    characterData: true,
    subtree: true,
  };
  // Pass in the target node, as well as the observer options
  observer.observe(document.querySelector("#block-region-content"), config);
});
