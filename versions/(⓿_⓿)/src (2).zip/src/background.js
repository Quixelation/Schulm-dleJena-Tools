//@ts-ignore
chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
    console.log({ request: request, sender: sender, sendResponse: sendResponse });
    if (request.message === "activate_icon") {
        chrome.pageAction.show(sender.tab.id);
    }
});
chrome.storage.sync.get(null, function (options) {
    if (Object.keys(options).length === 1) {
        chrome.storage.sync.set({
            usecoloredprogress: true,
            showemojicourses: true,
            autologinredirect: true
        });
    }
});
