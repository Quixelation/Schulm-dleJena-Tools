//@ts-nocheck
console.log("script.js");
chrome.runtime.sendMessage({ message: "activate_icon" });
chrome.storage.sync.get(null, function (options) {
    if (location.href === "https://www.mz.jena.de/moodle/" &&
        options["autologinredirect"] === true) {
        var loginContA = document.querySelector(".usermenu .login a");
        console.log({ loginContA: loginContA });
        if (loginContA) {
            location.replace("https://www.mz.jena.de/moodle/login/index.php");
        }
    }
    if (location.pathname.slice(-4) === ".pdf"
    // && href.slice(href.length - forceDownload.length) !== forceDownload
    ) {
        var forceDownload = "forcedownload=1";
        location.search = forceDownload;
    }
    if (location.href === "https://www.mz.jena.de/moodle/my/") {
        //console.log(String(document.querySelector("#block-region-content")));
    }
});
document.querySelector(".site-name").innerHTML += "\n  <span style=\"font-size: 0.75rem; display: block;margin-top: -4px\">w/ Moodle-Helper by Robert St\u00FCndl</span>\n";
