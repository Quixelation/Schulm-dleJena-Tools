chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  // If the received message has the expected format...
  if (msg.text === "report_back") {
    // Call the specified callback, passing
    // the web-page's DOM content as argument

    sendResponse(document.body.innerHTML);
  }
});

chrome.storage.sync.get(null, function (options) {
  document.querySelector("html").style.scrollBehavior = "smooth";
  console.log("script.js");
  chrome.runtime.sendMessage({ message: "activate_icon" });
  chrome.storage.sync.get(null, function (options) {
    if (location.href === "https://www.mz.jena.de/moodle/") {
      var loginContA = document.querySelector(".usermenu .login a");
      console.log({ loginContA });
      if (loginContA && options["autologinredirect"] === true) {
        location.replace("https://www.mz.jena.de/moodle/login/index.php");
      } else if (options["autodashboardredirect"] === true) {
        location.replace("https://www.mz.jena.de/moodle/my/");
      }
    } else if (
      location.href === "https://www.mz.jena.de/moodle/login/index.php"
    ) {
      var userIn = false;
      var passIn = false;
      document.getElementById("password").addEventListener("input", (e) => {
        if (true) {
          userIn = true;
          checkAndLogin();
        }
      });
      document.getElementById("username").addEventListener("input", (e) => {
        if (true) {
          passIn = true;
          checkAndLogin();
        }
      });
      function checkAndLogin() {
        console.log({ passIn, userIn });
        if (userIn && passIn && options["autologin_untrusted"]) {
          document.getElementById("loginbtn").click();
        }
      }
    }

    if (
      location.pathname.slice(-4) === ".pdf" &&
      options["forcedownload"] === true
      // && href.slice(href.length - forceDownload.length) !== forceDownload
    ) {
      const forceDownload = "forcedownload=1";
      location.search = forceDownload;
    }

    if (location.href === "https://www.mz.jena.de/moodle/my/") {
      //console.log(String(document.querySelector("#block-region-content")));
    }
  });

  document.querySelector(".site-name").innerHTML += `
  <span style="font-size: 0.75rem; display: block;margin-top: -4px">w/ Moodle-Helper by Robert Stündl</span>
`;
  //#region Navigation Panel
  var showCreateInsteadOfAllTodos = false;

  const asideElem = document.querySelector("#block-region-side-pre");
  const navTodoCard = document.createElement("div");
  navTodoCard.classList.add("block_navigation", "block", "card", "mb-3");
  navTodoCard.style.padding = "16px";

  console.log(navTodoCard);
  // const newNavSectionContentContainer = document.createElement("div");

  const todoSectionTitle = document.createElement("h5");
  todoSectionTitle.classList.add("card-title");
  todoSectionTitle.innerText = "Todo";
  navTodoCard.append(todoSectionTitle);

  const todoContainer = document.createElement("div");
  todoContainer.style.display = "flex";
  todoContainer.style.flexDirection = "column";

  const TodoContentContainer = document.createElement("div");

  TodoContentContainer.append(todoContainer);
  navTodoCard.append(TodoContentContainer);
  function createEmptyDiv() {
    const emptyDiv = document.createElement("div");
    emptyDiv.innerHTML = "&nbsp;";
    return emptyDiv;
  }
  //#region createTodo Container
  function showCreateTodo(name: string) {
    window.scrollTo(0, 0);
    console.log("show CReate Todo");

    const createTodoContainer = document.createElement("div");
    createTodoContainer.style.display = "none";
    createTodoContainer.style.flexDirection = "column";

    const createTodoContainer_course_text = document.createElement("div");
    createTodoContainer_course_text.innerText = "Kurs: " + name;
    createTodoContainer.append(createTodoContainer_course_text);
    createTodoContainer.append(createEmptyDiv());
    //#region name
    const createTodoContainer_name_text = document.createElement("h6");
    createTodoContainer_name_text.innerText = "Name";
    createTodoContainer.append(createTodoContainer_name_text);

    const createTodoContainer_name_input = document.createElement("input");
    createTodoContainer_name_input.type = "text";
    createTodoContainer.append(createTodoContainer_name_input);
    //#endregion
    createTodoContainer.append(createEmptyDiv());
    //#region type
    const createTodoContainer_type_text = document.createElement("h6");
    createTodoContainer_type_text.innerText = "Typ";
    createTodoContainer.append(createTodoContainer_type_text);

    const createTodoContainer_type_input = document.createElement("select");
    function createOption(name: string, value: string, preview?: boolean) {
      const selectOption = document.createElement("option");
      selectOption.value = value;
      selectOption.innerText = name;
      if (preview) {
        selectOption.selected = true;
        selectOption.disabled = true;
      }
      return selectOption;
    }
    createTodoContainer_type_input.append(createOption("Hausaufgabe", "ha"));
    createTodoContainer_type_input.append(createOption("Test", "exam"));
    createTodoContainer_type_input.append(
      createOption("Videokonferenz", "video")
    );
    createTodoContainer.append(createTodoContainer_type_input);
    //#endregion
    createTodoContainer.append(createEmptyDiv());
    //#region date
    const createTodoContainer_date_text = document.createElement("h6");
    createTodoContainer_date_text.innerText = "Datum";
    createTodoContainer.append(createTodoContainer_date_text);

    const createTodoContainer_date_input = document.createElement("input");
    createTodoContainer_date_input.type = "date";
    createTodoContainer.append(createTodoContainer_date_input);
    //#endregion
    createTodoContainer.append(createEmptyDiv());
    const finishCreateTodoBtn = document.createElement("button");
    finishCreateTodoBtn.innerText = "Erstellen";
    createTodoContainer.append(finishCreateTodoBtn);

    TodoContentContainer.innerHTML = createTodoContainer.innerHTML;
  }
  //#endregion

  asideElem.prepend(navTodoCard);
  //#endregion
  if (location.href.includes("https://www.mz.jena.de/moodle/my/")) {
    const Fächer = options["fächer"];
    const courseNames = [];
    var observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        console.log("Mutation");

        document
          .querySelectorAll(".card-deck .card[data-region='course-content']")
          .forEach((item) => {
            if (item.getAttribute("data-moodlehelperenhanced") == "true") {
              return;
            } else {
              item.setAttribute("data-moodlehelperenhanced", "true");
            }
            console.log("Changing Dashboard");

            // Rremove not need white bg
            let bgWhiteTempItem = item.querySelector(".bg-white");
            if (bgWhiteTempItem) {
              bgWhiteTempItem.classList.remove("bg-white");
            }

            // try {
            //   item.querySelector(".progress-bar.bar").remove();
            // } catch (err) {}

            try {
              const courseDropdownContainer = item.querySelector(
                ".ml-auto.dropdown"
              ) as HTMLDivElement;
              courseDropdownContainer.style.display = "flex";

              const dropdownBtn = courseDropdownContainer.querySelector(
                ".btn.btn-link.btn-icon"
              );

              const clonedDropdown = dropdownBtn.cloneNode(
                true
              ) as HTMLDivElement;

              clonedDropdown
                .querySelector("i")
                .classList.remove("fa-ellipsis-h");
              clonedDropdown.querySelector("i").classList.add("fa-plus");
              const itemName =
                item.children[1].children[0].children[0].children[1].children[2]
                  ?.textContent;
              clonedDropdown.addEventListener(
                "click",
                function (event) {
                  console.log(event);
                  showCreateTodo(itemName);
                  event.stopPropagation();
                },
                true
              );
              courseDropdownContainer.append(clonedDropdown);
            } catch (err) {
              console.warn(err);
            }
            try {
              const name =
                item.children[1].children[0].children[0].children[1].children[2]
                  .textContent;
              const filtered = Object.keys(Fächer).filter((item) =>
                name.includes(item)
              );
              courseNames.push(name);
              if (filtered.length === 1) {
                if (options["shortcoursenames"] === true) {
                  item.children[1].children[0].children[0].children[1].children[2].textContent =
                    filtered[0];
                  item.children[1].children[0].children[0].children[1].children[2].setAttribute(
                    "data-moodlehelperfilteredname",
                    "true"
                  );
                  (item.children[1].children[0].children[0].children[1]
                    .children[2] as HTMLSpanElement).style.fontSize = "20px";
                  item.children[1].children[0].children[0].children[0].children[1].textContent =
                    "";
                }

                if (
                  /*Gibt Emoji für dieses Fach*/ Fächer[filtered[0]] != null &&
                  Fächer[filtered[0]] != "" &&
                  Fächer[filtered[0]] != false &&
                  Fächer[filtered[0]] != undefined &&
                  options["showemojicourses"] === true
                ) {
                  (item.children[0]
                    .children[0] as HTMLDivElement).style.backgroundImage = `url("\
data:image/svg+xml;utf8, \
  <svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='170px' height='50px'> \
    <rect x='0' y='0' width='170' height='50'\
      style=' \
             \
             fill:%23334155 ;  fill-opacity: 0.7; '/> \
    <text x='85' y='30' \
      style='fill:%2339CCCC; text-anchor: middle; font-family:Arial' font-size='24' \
      transform=''> \
      ${Fächer[filtered[0]]} \
    </text> \
  </svg>\
")`;
                }
              }
              // Wenn nicht 100% Fortschritt, dann Titel Fett
              if (
                item
                  .querySelector(".progress-bar.bar")
                  ?.getAttribute("aria-valuenow") != "100"
              ) {
                (item.children[1].children[0].children[0].children[1]
                  .children[2] as HTMLSpanElement).style.fontWeight = "bold";
              }

              (item as HTMLDivElement).style.backgroundColor = "#0f172a";
              var smallFooterCard = item.querySelector(
                ".card-footer .small"
              ) as HTMLSpanElement;
              if (smallFooterCard) smallFooterCard.style.color = "#cbd5e1";

              try {
                (item.children[1].children[0].children[0].children[1]
                  .children[2] as HTMLSpanElement).style.color = `#39CCCC`;
                var theProgressBar = item.querySelector(
                  ".progress-bar.bar"
                ) as HTMLDivElement;
                if (theProgressBar) {
                  theProgressBar.style.backgroundColor = `#39CCCC`;
                }
              } catch (err) {
                console.error("Default Colors Assign Error!", err);
              }

              if (options["usecoloredprogress"] === true) {
                if (item.querySelector(".progress-bar.bar") != null) {
                  const maxChars = 100;

                  var Hsl =
                    (Number(
                      item
                        .querySelector(".progress-bar.bar")
                        .getAttribute("aria-valuenow")
                    ) *
                      127) /
                    100;
                  (item.children[1].children[0].children[0].children[1]
                    .children[2] as HTMLSpanElement).style.color = `hsla(${Hsl}, 100%, 50%, 1)`;
                  (item.querySelector(
                    ".progress-bar.bar"
                  ) as HTMLDivElement).style.backgroundColor = `hsla(${Hsl}, 100%, 50%, 1)`;
                }
              }
            } catch (err) {
              console.warn(err);
            }
          });
      });
    });

    // Configuration of the observer:
    var config = {
      attributes: true,
      childList: true,
      characterData: true,
      subtree: true,
    };

    // Pass in the target node, as well as the observer options
    observer.observe(document.querySelector("#block-region-content"), config);
  }
});
