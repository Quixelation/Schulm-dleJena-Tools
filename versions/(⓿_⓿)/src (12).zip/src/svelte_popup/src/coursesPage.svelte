<script lang="ts">
  import { findCourses } from "./ts/courses";
  import CoursesAutoDetectTR from "./coursesPageAutoDetectTableRow.svelte";
  let detectedCourses;
  let handleAutoDetec = () => {
    console.log("click");
    chrome.tabs.query({ active: true, currentWindow: true }, (tab) => {
      console.log(tab[0]);
      chrome.tabs.sendMessage(tab[0].id, { text: "report_back" }, (val) => {
        const detec = findCourses(val);
        detectedCourses = detec;
        console.log(detec);
      });
    });
  };
  import Button from "./Button.svelte";
</script>

<div id="coursePage" class="Page">
  <h2
    id="findCoursesHeader"
    on:click={() => {
      handleAutoDetec();
    }}
  >Kurse erkennen</h2>
  <p>Kurse automatisch erkennen lassen.</p>
  <Button
    title="Auto"
    on:click={() => {
      handleAutoDetec();
    }}
  />
  <div id="detectedCourses">
    {detectedCourses}
    {#if detectedCourses != null && detectedCourses.length > 0}
      <table class="detectedCoursesList">
        {#each detectedCourses as course, index}
          <CoursesAutoDetectTR courseName={course} />
        {/each}
      </table>
    {:else}
      Keine <em>neuen</em> Kurse gefunden.
    {/if}
  </div>
  <hr />
</div>

<style lang="scss">
  #coursePage {
    #findCoursesHeader {
      margin-bottom: 0px;
      & ~ p {
        margin-top: 0px;
      }
    }
    #detectedCourses {
      table.detectedCoursesList {
      }
    }
  }
</style>
