<script lang="ts">
  export let optionCode;
  export let title;
  export let desc;
  let value;
  chrome.storage.sync.get(null, function (options) {
    value = options[optionCode];
  });
  let inputHandler = (e) => {
    chrome.storage.sync.set(
      { [optionCode]: (e.target as HTMLInputElement).checked },
      () => {
        console.log("Value is set to ", (e.target as HTMLInputElement).checked);
      }
    );
  };
</script>

<div>
  <label style="display: flex; justify-content: space-between;"
    ><div class="FunctionDetails">
      <div class="functionTitle">{title}</div>
      <div class="functionDesc">{desc}</div>
    </div>
    <input on:input={inputHandler} type="checkbox" checked={value} /></label
  >
</div>

<style lang="scss">
  .FunctionDetails {
    display: flex;
    flex-direction: column;
    .functionTitle {
      font-weight: bold;
      font-size: 14px;
    }
    .functionDesc {
      font-size: 12px;
    }
  }
</style>
