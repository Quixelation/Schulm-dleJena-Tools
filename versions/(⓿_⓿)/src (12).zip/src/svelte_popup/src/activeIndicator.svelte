<script>
  const isActive = false;
</script>

<div>
  Tools sind {#if isActive}<span style="color: #2ECC40">aktiv</span>{:else}<span
      style="color: #FF4136">inaktiv</span
    >{/if}!
</div>

<style>
  div {
    font-size: 13px;
    text-align: center;
    padding: 8px;
  }
  span {
    font-weight: 700;
  }
</style>
