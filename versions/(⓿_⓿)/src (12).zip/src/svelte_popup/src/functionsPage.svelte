<script lang="ts">
  import FunctionToggle from "./functionToggleCheckbox.svelte";
</script>

<h2 class="pageHeader">Funktionen</h2>
<div style="width: 100%; display: flex; flex-direction: column">
  <FunctionToggle
    title="Kurze Kursnamen"
    desc="Verkürztzt die Namen der Kurse auf das wichtigste."
    optionCode="shortcoursenames"
  />
  <hr />
  <FunctionToggle
    title="Auto Login-Redirect"
    desc="Automatisch zur Login-Seite gehen."
    optionCode="autologinredirect"
  />
  <hr />
  <FunctionToggle
    title="Kurze Kursnamen"
    desc="Kursnamen werden gekürzt."
    optionCode="shortcoursenames"
  />
  <hr />
  <FunctionToggle
    title="Farbiger Fortschritt"
    desc="Kursname wird je nach Fortschritt gefärbt. (von rot zu grün)"
    optionCode="usecoloredprogress"
  />
  <hr />
  <FunctionToggle
    title="Emoji-Kursbilder"
    desc="Kurse haben Emojis als Thumbnails."
    optionCode="showemojicourses"
  />
  <hr />
  <FunctionToggle
    title="Auto Dashboard"
    desc="Startseite leitet automatisch zum Dashboard weiter."
    optionCode="autodashboardredirect"
  />
  <hr />
  <FunctionToggle
    title="Download erzwingen"
    desc="Dateien werden automatisch heruntergeladen"
    optionCode="forcedownload"
  />
  <hr />
  <FunctionToggle
    title="AutoFill-AutoLogin"
    desc="!!! Automatischen Klicken des Einloggen Knopfes bei Eingabe. Nur für AutoFill!!!"
    optionCode="autologin_untrusted"
  />
</div>

<style lang="scss">
  .pageHeader {
    margin-top: 0px;
  }
  hr {
    width: 100%;
  }
</style>
