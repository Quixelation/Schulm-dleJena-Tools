const fächer = {
  Kunst: "🎨",
  Astronomie: "🌌",
  Ethik: "",
  Sport: "🏀",
  Englisch: "",
  Deutsch: "",
  Französisch: "🥖",
  Mathe: "📊",
  Biologie: "🌸",
  Chemie: "🧪",
  Geographie: "🌎",
  Musik: "🎶",
  Physik: "⚛️",
  Sozialkunde: "",
  WR: "📈",
  Geschichte: "",
  Informatik: "👩‍💻",
  DG: "🎭",
};

function findCourses(givenInnerHTML: string) {
  const doc = document.createElement("div");
  doc.innerHTML = givenInnerHTML;

  const foundCourses: string[] = [];

  doc
    .querySelectorAll(".card-deck .card[data-region='course-content']")
    .forEach((item) => {
      const name =
        item.children[1].children[0].children[0].children[1].children[2]
          .textContent;
      if (
        item.children[1].children[0].children[0].children[1].children[2].getAttribute(
          "data-moodlehelperfilteredname"
        ) != "true"
      ) {
      }
      if (!foundCourses.includes(name)) {
        foundCourses.push(name);
      }
    });
  return foundCourses;
}

function getAutoCourseName(longName: string) {
  const filtered = Object.keys(fächer).filter((item) =>
    longName.includes(item)
  );

  if (filtered.length === 1) {
    return filtered[0];
  } else {
    return null;
  }
}

function getAutoAssets(courseName: string) {
  return fächer[courseName];
}

export { findCourses, getAutoCourseName, getAutoAssets };
