<script lang="ts">
  import ActiveIndicator from "./activeIndicator.svelte";
  import Button from "./Button.svelte";
  import CoursesPage from "./coursesPage.svelte";
  import FunctionsPage from "./functionsPage.svelte";
  const mainPage = document.getElementById("mainPage");
  const coursePage = document.getElementById("coursePage");
  let activePage = "mainPage";
</script>

<div
  class="PopUpTitleContainer"
  on:click={() => {
    activePage = "mainPage";
  }}
>
  <div class="PopUpTitle">
    <h2 class="title" style="margin-bottom: 0px">SchulmoodleJena Tools</h2>
    <h5 style="margin-top: 0px">by Robert Stündl</h5>
  </div>
</div>
<div id="router">
  {#if activePage === "mainPage"}
    <div id="mainPage" class="Page">
      <div class="linkList">
        <div
          class="linkListItem"
          on:click={() => {
            activePage = "functionsPage";
          }}
        >
          <div class="text">Funktionen</div>
          <div class="icon">
            <svg
              width="11px"
              height="11px"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg">
              <title>prime</title>
              <g
                id="880b5b52-5578-436c-a64a-10a281e56ea6"
                data-name="Arrow Left">
                <path
                  d="M7.77,23.58l-2.24-2a0.5,0.5,0,0,1,0-.71L13.43,12,5.5,3.13a0.5,0.5,0,0,1,0-.71l2.24-2a0.5,0.5,0,0,1,.71,0L18.8,12,8.48,23.54A0.5,0.5,0,0,1,7.77,23.58Z"
                />
              </g>
            </svg>
          </div>
        </div>
        <div
          class="linkListItem"
          on:click={() => {
            activePage = "coursePage";
          }}
        >
          <div class="text">Kurse</div>
          <div class="icon">
            <svg
              width="11px"
              height="11px"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg">
              <title>prime</title>
              <g
                id="880b5b52-5578-436c-a64a-10a281e56ea6"
                data-name="Arrow Left">
                <path
                  d="M7.77,23.58l-2.24-2a0.5,0.5,0,0,1,0-.71L13.43,12,5.5,3.13a0.5,0.5,0,0,1,0-.71l2.24-2a0.5,0.5,0,0,1,.71,0L18.8,12,8.48,23.54A0.5,0.5,0,0,1,7.77,23.58Z"
                />
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
  {:else if activePage === "functionsPage"}
    <FunctionsPage />
  {:else if activePage === "coursePage"}
    <CoursesPage />
  {:else}
    404
  {/if}
</div>
<ActiveIndicator />

<style lang="scss">
  $bodyMargin: 10px;
  :global(body) {
    margin: 0px;
    padding: 0px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
      Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  }

  .PopUpTitleContainer {
    position: sticky;
    top: 0px;
    left: 0px;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
    background-color: #ff3e00;
    padding: $bodyMargin;
    .PopUpTitle {
      color: white;
      h2 {
        margin: 0px;
        font-size: 1.25rem;
      }
      h5 {
        margin: 0px;
        font-weight: 400;
      }
    }
  }
  #router {
    padding: $bodyMargin;
  }

  .linkList {
    display: flex;
    flex-direction: column;
    .linkListItem {
      cursor: pointer;
      padding: {
        left: 5px + $bodyMargin;
        right: 5px + $bodyMargin;
      }
      height: 45px;

      display: flex;
      justify-content: space-between;
      align-items: center;
      width: -webkit-fill-available;
      margin-left: -$bodyMargin;
      margin-right: -$bodyMargin;
      .text {
        margin-right: 10px;
        font-size: 14px;
        position: relative;
        text-decoration: none;
        color: black;

        &:after {
          content: "";
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          height: 0.1em;
          min-height: 1px;
          background-color: currentColor;
          transform: scaleX(0);
          transform-origin: left;
          transition: transform 0.25s ease;
        }
      }
      &:hover {
        .text:after {
          transform: scaleX(1);
        }
      }
      .icon {
      }
      border-top: solid 0.75px rgb(172, 172, 172);
      &:last-of-type {
        border-bottom: solid 0.75px rgb(172, 172, 172);
      }
    }
  }
</style>
