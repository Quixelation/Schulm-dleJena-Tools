console.log("Hello from adjustVid");
window.addEventListener("load", function () {
    document.querySelectorAll("video.vjs-tech").forEach(function (item) {
        console.log(item);
        item.parentElement.style.paddingTop = "min(" + 
        //@ts-ignore
        item.parentElement.computedStyleMap().get("padding-top")
            .value + "%, calc(100vh - 50px))";
        item.parentElement.style.paddingTop = "min(" + 
        //@ts-ignore
        item.parentElement.computedStyleMap().get("padding-top")
            .value + "%, -webkit-calc(100vh - 50px))";
        item.parentElement.parentElement.style.maxWidth = "";
    });
});
