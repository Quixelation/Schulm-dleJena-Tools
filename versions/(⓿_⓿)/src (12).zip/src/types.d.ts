type todoType = "video" | "exam" | "ha";
interface todoItem {
  course: string;
  name: string;
  date: number;
  type: todoType;
  mandatory: boolean;
  link: string;
}
export { todoItem, todoType };
