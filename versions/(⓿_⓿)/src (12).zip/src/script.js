chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    // If the received message has the expected format...
    if (msg.text === "report_back") {
        // Call the specified callback, passing
        // the web-page's DOM content as argument
        sendResponse(document.body.innerHTML);
    }
});
chrome.storage.sync.get(null, function (options) {
    document.querySelector("html").style.scrollBehavior = "smooth";
    console.log("script.js");
    chrome.runtime.sendMessage({ message: "activate_icon" });
    chrome.storage.sync.get(null, function (options) {
        if (location.href === "https://www.mz.jena.de/moodle/") {
            var loginContA = document.querySelector(".usermenu .login a");
            console.log({ loginContA: loginContA });
            if (loginContA && options["autologinredirect"] === true) {
                location.replace("https://www.mz.jena.de/moodle/login/index.php");
            }
            else if (options["autodashboardredirect"] === true) {
                location.replace("https://www.mz.jena.de/moodle/my/");
            }
        }
        else if (location.href === "https://www.mz.jena.de/moodle/login/index.php") {
            var userIn = false;
            var passIn = false;
            document.getElementById("password").addEventListener("input", function (e) {
                if (true) {
                    userIn = true;
                    checkAndLogin();
                }
            });
            document.getElementById("username").addEventListener("input", function (e) {
                if (true) {
                    passIn = true;
                    checkAndLogin();
                }
            });
            function checkAndLogin() {
                console.log({ passIn: passIn, userIn: userIn });
                if (userIn && passIn && options["autologin_untrusted"]) {
                    document.getElementById("loginbtn").click();
                }
            }
        }
        if (location.pathname.slice(-4) === ".pdf" &&
            options["forcedownload"] === true
        // && href.slice(href.length - forceDownload.length) !== forceDownload
        ) {
            var forceDownload = "forcedownload=1";
            location.search = forceDownload;
        }
        if (location.href === "https://www.mz.jena.de/moodle/my/") {
            //console.log(String(document.querySelector("#block-region-content")));
        }
    });
    document.querySelector(".site-name").innerHTML += "\n  <span style=\"font-size: 0.75rem; display: block;margin-top: -4px\">w/ Moodle-Helper by Robert St\u00FCndl</span>\n";
    //#region Navigation Panel
    var showCreateInsteadOfAllTodos = false;
    var asideElem = document.querySelector("#block-region-side-pre");
    var navTodoCard = document.createElement("div");
    navTodoCard.classList.add("block_navigation", "block", "card", "mb-3");
    navTodoCard.style.padding = "16px";
    console.log(navTodoCard);
    // const newNavSectionContentContainer = document.createElement("div");
    var todoSectionTitle = document.createElement("h5");
    todoSectionTitle.classList.add("card-title");
    todoSectionTitle.innerText = "Todo";
    navTodoCard.append(todoSectionTitle);
    var todoContainer = document.createElement("div");
    todoContainer.style.display = "flex";
    todoContainer.style.flexDirection = "column";
    var TodoContentContainer = document.createElement("div");
    TodoContentContainer.append(todoContainer);
    navTodoCard.append(TodoContentContainer);
    function createEmptyDiv() {
        var emptyDiv = document.createElement("div");
        emptyDiv.innerHTML = "&nbsp;";
        return emptyDiv;
    }
    //#region createTodo Container
    function showCreateTodo(name) {
        window.scrollTo(0, 0);
        console.log("show CReate Todo");
        var createTodoContainer = document.createElement("div");
        createTodoContainer.style.display = "none";
        createTodoContainer.style.flexDirection = "column";
        var createTodoContainer_course_text = document.createElement("div");
        createTodoContainer_course_text.innerText = "Kurs: " + name;
        createTodoContainer.append(createTodoContainer_course_text);
        createTodoContainer.append(createEmptyDiv());
        //#region name
        var createTodoContainer_name_text = document.createElement("h6");
        createTodoContainer_name_text.innerText = "Name";
        createTodoContainer.append(createTodoContainer_name_text);
        var createTodoContainer_name_input = document.createElement("input");
        createTodoContainer_name_input.type = "text";
        createTodoContainer.append(createTodoContainer_name_input);
        //#endregion
        createTodoContainer.append(createEmptyDiv());
        //#region type
        var createTodoContainer_type_text = document.createElement("h6");
        createTodoContainer_type_text.innerText = "Typ";
        createTodoContainer.append(createTodoContainer_type_text);
        var createTodoContainer_type_input = document.createElement("select");
        function createOption(name, value, preview) {
            var selectOption = document.createElement("option");
            selectOption.value = value;
            selectOption.innerText = name;
            if (preview) {
                selectOption.selected = true;
                selectOption.disabled = true;
            }
            return selectOption;
        }
        createTodoContainer_type_input.append(createOption("Hausaufgabe", "ha"));
        createTodoContainer_type_input.append(createOption("Test", "exam"));
        createTodoContainer_type_input.append(createOption("Videokonferenz", "video"));
        createTodoContainer.append(createTodoContainer_type_input);
        //#endregion
        createTodoContainer.append(createEmptyDiv());
        //#region date
        var createTodoContainer_date_text = document.createElement("h6");
        createTodoContainer_date_text.innerText = "Datum";
        createTodoContainer.append(createTodoContainer_date_text);
        var createTodoContainer_date_input = document.createElement("input");
        createTodoContainer_date_input.type = "date";
        createTodoContainer.append(createTodoContainer_date_input);
        //#endregion
        createTodoContainer.append(createEmptyDiv());
        var finishCreateTodoBtn = document.createElement("button");
        finishCreateTodoBtn.innerText = "Erstellen";
        createTodoContainer.append(finishCreateTodoBtn);
        TodoContentContainer.innerHTML = createTodoContainer.innerHTML;
    }
    //#endregion
    asideElem.prepend(navTodoCard);
    //#endregion
    if (location.href.includes("https://www.mz.jena.de/moodle/my/")) {
        var Fächer_1 = options["fächer"];
        var courseNames_1 = [];
        var observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                console.log("Mutation");
                document
                    .querySelectorAll(".card-deck .card[data-region='course-content']")
                    .forEach(function (item) {
                    var _a, _b;
                    if (item.getAttribute("data-moodlehelperenhanced") == "true") {
                        return;
                    }
                    else {
                        item.setAttribute("data-moodlehelperenhanced", "true");
                    }
                    console.log("Changing Dashboard");
                    // Rremove not need white bg
                    var bgWhiteTempItem = item.querySelector(".bg-white");
                    if (bgWhiteTempItem) {
                        bgWhiteTempItem.classList.remove("bg-white");
                    }
                    // try {
                    //   item.querySelector(".progress-bar.bar").remove();
                    // } catch (err) {}
                    try {
                        var courseDropdownContainer = item.querySelector(".ml-auto.dropdown");
                        courseDropdownContainer.style.display = "flex";
                        var dropdownBtn = courseDropdownContainer.querySelector(".btn.btn-link.btn-icon");
                        var clonedDropdown = dropdownBtn.cloneNode(true);
                        clonedDropdown
                            .querySelector("i")
                            .classList.remove("fa-ellipsis-h");
                        clonedDropdown.querySelector("i").classList.add("fa-plus");
                        var itemName_1 = (_a = item.children[1].children[0].children[0].children[1].children[2]) === null || _a === void 0 ? void 0 : _a.textContent;
                        clonedDropdown.addEventListener("click", function (event) {
                            console.log(event);
                            showCreateTodo(itemName_1);
                            event.stopPropagation();
                        }, true);
                        courseDropdownContainer.append(clonedDropdown);
                    }
                    catch (err) {
                        console.warn(err);
                    }
                    try {
                        var name_1 = item.children[1].children[0].children[0].children[1].children[2]
                            .textContent;
                        var filtered = Object.keys(Fächer_1).filter(function (item) {
                            return name_1.includes(item);
                        });
                        courseNames_1.push(name_1);
                        if (filtered.length === 1) {
                            if (options["shortcoursenames"] === true) {
                                item.children[1].children[0].children[0].children[1].children[2].textContent =
                                    filtered[0];
                                item.children[1].children[0].children[0].children[1].children[2].setAttribute("data-moodlehelperfilteredname", "true");
                                item.children[1].children[0].children[0].children[1]
                                    .children[2].style.fontSize = "20px";
                                item.children[1].children[0].children[0].children[0].children[1].textContent =
                                    "";
                            }
                            if (
                            /*Gibt Emoji für dieses Fach*/ Fächer_1[filtered[0]] != null &&
                                Fächer_1[filtered[0]] != "" &&
                                Fächer_1[filtered[0]] != false &&
                                Fächer_1[filtered[0]] != undefined &&
                                options["showemojicourses"] === true) {
                                item.children[0]
                                    .children[0].style.backgroundImage = "url(\"data:image/svg+xml;utf8,   <svg xmlns='http://www.w3.org/2000/svg' version='1.1' width='170px' height='50px'>     <rect x='0' y='0' width='170' height='50'      style='                           fill:%23334155 ;  fill-opacity: 0.7; '/>     <text x='85' y='30'       style='fill:%2339CCCC; text-anchor: middle; font-family:Arial' font-size='24'       transform=''>       " + Fächer_1[filtered[0]] + "     </text>   </svg>\")";
                            }
                        }
                        // Wenn nicht 100% Fortschritt, dann Titel Fett
                        if (((_b = item
                            .querySelector(".progress-bar.bar")) === null || _b === void 0 ? void 0 : _b.getAttribute("aria-valuenow")) != "100") {
                            item.children[1].children[0].children[0].children[1]
                                .children[2].style.fontWeight = "bold";
                        }
                        item.style.backgroundColor = "#0f172a";
                        var smallFooterCard = item.querySelector(".card-footer .small");
                        if (smallFooterCard)
                            smallFooterCard.style.color = "#cbd5e1";
                        try {
                            item.children[1].children[0].children[0].children[1]
                                .children[2].style.color = "#39CCCC";
                            var theProgressBar = item.querySelector(".progress-bar.bar");
                            if (theProgressBar) {
                                theProgressBar.style.backgroundColor = "#39CCCC";
                            }
                        }
                        catch (err) {
                            console.error("Default Colors Assign Error!", err);
                        }
                        if (options["usecoloredprogress"] === true) {
                            if (item.querySelector(".progress-bar.bar") != null) {
                                var maxChars = 100;
                                var Hsl = (Number(item
                                    .querySelector(".progress-bar.bar")
                                    .getAttribute("aria-valuenow")) *
                                    127) /
                                    100;
                                item.children[1].children[0].children[0].children[1]
                                    .children[2].style.color = "hsla(" + Hsl + ", 100%, 50%, 1)";
                                item.querySelector(".progress-bar.bar").style.backgroundColor = "hsla(" + Hsl + ", 100%, 50%, 1)";
                            }
                        }
                    }
                    catch (err) {
                        console.warn(err);
                    }
                });
            });
        });
        // Configuration of the observer:
        var config = {
            attributes: true,
            childList: true,
            characterData: true,
            subtree: true
        };
        // Pass in the target node, as well as the observer options
        observer.observe(document.querySelector("#block-region-content"), config);
    }
});
